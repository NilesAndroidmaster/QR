package com.qrgridscanner.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.qrgridscanner.R
import com.qrgridscanner.databinding.ActivityGridViewBinding
import com.qrgridscanner.model.QRCode
import com.qrgridscanner.model.QRGrid

/**
 * GridViewActivity — post-scan results screen with two tabs.
 *
 * Tab 0 — GRID VIEW
 *   Rectangular grid (rows x cols) with GridLayoutManager.
 *   Scanned = blue cell.  Empty slot = grey cell (Option A).
 *   Low confidence = purple tint.
 *
 * Tab 1 — CODE LIST
 *   Row-major sorted flat list: full content, row, col, confidence.
 */
class GridViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGridViewBinding
    private val viewModel: ScannerViewModel by viewModels()

    private lateinit var grid: QRGrid
    private lateinit var codes: List<QRCode>
    private var cols = 1
    private var rows = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGridViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        grid  = viewModel.getGrid()
        codes = viewModel.getSortedCodes()
        cols  = grid.totalCols.coerceAtLeast(1)
        rows  = grid.totalRows.coerceAtLeast(1)

        binding.tvGridInfo.text =
            "${codes.size} codes  ·  $rows row${if (rows != 1) "s" else ""}  ×  $cols col${if (cols != 1) "s" else ""}"

        binding.btnBack.setOnClickListener { finish() }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> showGridTab()
                    1 -> showListTab()
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        showGridTab()
    }

    // -------------------------------------------------------------------------
    // Tab 0: Visual Grid
    // -------------------------------------------------------------------------

    private fun showGridTab() {
        val lookup = codes.associateBy { Pair(it.gridRow, it.gridCol) }
        val cells  = mutableListOf<QRCode?>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                cells.add(lookup[Pair(r, c)])
            }
        }

        binding.recyclerView.itemAnimator = null
        binding.recyclerView.layoutManager = GridLayoutManager(this, cols)
        binding.recyclerView.adapter = GridCellAdapter(cells)
        // Remove any list dividers that might have been set by list tab
        while (binding.recyclerView.itemDecorationCount > 0) {
            binding.recyclerView.removeItemDecorationAt(0)
        }
    }

    // -------------------------------------------------------------------------
    // Tab 1: Code List
    // -------------------------------------------------------------------------

    private fun showListTab() {
        binding.recyclerView.itemAnimator = null
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        while (binding.recyclerView.itemDecorationCount > 0) {
            binding.recyclerView.removeItemDecorationAt(0)
        }
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
        binding.recyclerView.adapter = CodeListAdapter(codes)
    }

    // =========================================================================
    // Adapter: Grid cells
    // =========================================================================

    inner class GridCellAdapter(
        private val cells: List<QRCode?>
    ) : RecyclerView.Adapter<GridCellAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvContent:  TextView = view.findViewById(R.id.tvCellContent)
            val tvPosition: TextView = view.findViewById(R.id.tvCellPosition)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_grid_cell, parent, false))

        override fun getItemCount() = cells.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val code = cells[position]
            if (code != null) {
                holder.tvContent.text  = code.id.take(16)
                holder.tvPosition.text = "R${code.gridRow} · C${code.gridCol}"
                val bg = if (code.confidence >= 1.0f)
                    getColor(R.color.cell_scanned)
                else
                    getColor(R.color.cell_low_confidence)
                holder.itemView.setBackgroundColor(bg)
                holder.tvContent.setTextColor(Color.WHITE)
                holder.tvPosition.setTextColor(Color.parseColor("#BBDEFF"))
                holder.tvContent.visibility  = View.VISIBLE
                holder.tvPosition.visibility = View.VISIBLE
            } else {
                // Empty slot
                holder.tvContent.visibility  = View.GONE
                holder.tvPosition.visibility = View.GONE
                holder.itemView.setBackgroundColor(getColor(R.color.cell_empty))
            }
        }
    }

    // =========================================================================
    // Adapter: Code list
    // =========================================================================

    inner class CodeListAdapter(
        private val codes: List<QRCode>
    ) : RecyclerView.Adapter<CodeListAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvIndex:      TextView = view.findViewById(R.id.tvListIndex)
            val tvContent:    TextView = view.findViewById(R.id.tvListContent)
            val tvRowCol:     TextView = view.findViewById(R.id.tvListRowCol)
            val tvConfidence: TextView = view.findViewById(R.id.tvListConfidence)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_code_list, parent, false))

        override fun getItemCount() = codes.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val code = codes[position]
            holder.tvIndex.text   = "#${position + 1}"
            holder.tvContent.text = code.id
            holder.tvRowCol.text  = "Row ${code.gridRow}   Col ${code.gridCol}"
            if (code.confidence >= 1.0f) {
                holder.tvConfidence.text = "✓ confirmed"
                holder.tvConfidence.setTextColor(getColor(R.color.accent_cyan))
            } else {
                holder.tvConfidence.text = "~ estimated"
                holder.tvConfidence.setTextColor(getColor(R.color.accent_yellow))
            }
        }
    }
}
