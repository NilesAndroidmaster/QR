package com.qrgridscanner.scanner

import android.content.Context
import android.util.Size
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import java.util.concurrent.Executors

/**
 * CameraConfig selects the best camera resolution for QR scanning.
 *
 * For Samsung S25 Ultra (and similarly spec'd flagship phones) the rear camera
 * supports up to 200 MP, but ML Kit works best with a 4K or Full-HD image
 * analysis stream because:
 *  - Higher resolution increases latency with no barcode-recognition benefit
 *  - 4K (3840×2160) gives excellent spatial resolution for small QR codes
 *  - ML Kit's barcode detector internally down-samples anyway
 *
 * Strategy:
 *  Preview  → match device display (highest quality the Preview surface can show)
 *  Analysis → 4K preferred, fallback 1080p, then 720p
 */
object CameraConfig {

    /**
     * Target analysis sizes in preference order.
     *
     * Samsung S25 Ultra rear camera (200 MP sensor) supports native 8K video capture
     * at 7680×4320. We request 8K first so that tiny QR codes spread across a large
     * physical grid are resolved with maximum spatial detail.
     *
     * CameraX will automatically fall back to the next supported size if 8K is not
     * available on the device or the current camera session.
     *
     * Note: 8K frames are large (~33 MP per frame). ML Kit will internally down-sample
     * before decoding, so latency increases only modestly while spatial resolution —
     * critical for detecting small/dense QR codes — is maximised.
     */
    private val PREFERRED_ANALYSIS_SIZES = listOf(
        Size(7680, 4320),  // 8K UHD  ← S25 Ultra native sensor resolution tier
        Size(3840, 2160),  // 4K UHD  ← fallback 1
        Size(2560, 1440),  // QHD     ← fallback 2
        Size(1920, 1080),  // Full HD  ← fallback 3
        Size(1280, 720)    // HD       ← minimum acceptable
    )

    /**
     * Build a [ResolutionSelector] that tries to pick the best available size
     * for image analysis, starting at 8K.
     */
    fun buildAnalysisResolutionSelector(): ResolutionSelector {
        // Request 8K as the upper bound; CameraX falls back gracefully if unavailable.
        return ResolutionSelector.Builder()
            .setResolutionStrategy(
                ResolutionStrategy(
                    PREFERRED_ANALYSIS_SIZES.first(),  // 8K as preferred bound
                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            )
            .setAspectRatioStrategy(
                AspectRatioStrategy(
                    AspectRatio.RATIO_16_9,
                    AspectRatioStrategy.FALLBACK_RULE_AUTO
                )
            )
            .build()
    }

    /**
     * Build a [ResolutionSelector] for the Preview use-case.
     * We use the highest supported preview resolution (typically 1080p or 4K preview).
     */
    fun buildPreviewResolutionSelector(): ResolutionSelector {
        return ResolutionSelector.Builder()
            .setAspectRatioStrategy(
                AspectRatioStrategy(
                    AspectRatio.RATIO_16_9,
                    AspectRatioStrategy.FALLBACK_RULE_AUTO
                )
            )
            .build()
    }

    /** Single-thread executor for image analysis (avoids frame queuing). */
    fun newAnalysisExecutor() = Executors.newSingleThreadExecutor()
}
