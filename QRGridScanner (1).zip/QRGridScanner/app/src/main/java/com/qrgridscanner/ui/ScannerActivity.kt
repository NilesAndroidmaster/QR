package com.qrgridscanner.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.qrgridscanner.R
import com.qrgridscanner.databinding.ActivityScannerBinding
import com.qrgridscanner.scanner.CameraConfig
import com.qrgridscanner.scanner.QRScanner
import java.util.concurrent.ExecutorService

class ScannerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScannerBinding
    private val viewModel: ScannerViewModel by viewModels()

    private lateinit var qrScanner: QRScanner
    private lateinit var analysisExecutor: ExecutorService

    private var camera: Camera? = null
    private var minZoom = 1f
    private var maxZoom = 10f
    private var currentZoom = 1f

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else { Toast.makeText(this, "Camera permission required.", Toast.LENGTH_LONG).show(); finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScannerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        qrScanner        = QRScanner()
        analysisExecutor = CameraConfig.newAnalysisExecutor()

        setupUI()
        observeViewModel()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        qrScanner.close()
        analysisExecutor.shutdown()
    }

    // ── UI setup ───────────────────────────────────────────────────────────────

    private fun setupUI() {
        binding.btnBack.setOnClickListener { finish() }

        // Add Row — user moves camera below current scan area
        binding.btnAddRow.setOnClickListener {
            viewModel.addRow()
        }

        // Finish — end session, save, open results screen
        binding.btnFinish.setOnClickListener {
            if (viewModel.getGrid().count() == 0) {
                Toast.makeText(this, "No codes scanned yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewModel.finish()
            viewModel.saveResults { file ->
                Toast.makeText(this, "Saved: ${file.name}", Toast.LENGTH_SHORT).show()
            }
            startActivity(Intent(this, GridViewActivity::class.java))
        }

        // Zoom seekbar
        binding.seekbarZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) setZoom(minZoom + (progress / 100f) * (maxZoom - minZoom))
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        binding.btnZoomIn.setOnClickListener  { adjustZoom(+0.5f) }
        binding.btnZoomOut.setOnClickListener { adjustZoom(-0.5f) }

        // Wire scanner frame callback
        qrScanner.onFrameDetected = { frame -> viewModel.onFrameDetected(frame) }
    }

    // ── ViewModel observation ─────────────────────────────────────────────────

    private fun observeViewModel() {

        viewModel.scannedCount.observe(this) { count ->
            binding.tvCount.text = "Scanned: $count"
        }

        viewModel.gridLiveData.observe(this) { grid ->
            val highlighted = viewModel.activeDetections.value
                ?.map { it.value }?.toSet() ?: emptySet()
            binding.gridOverview.updateGrid(grid, highlighted)
        }

        viewModel.activeDetections.observe(this) { detections ->
            val scannedIds = viewModel.getGrid().codes.keys
            binding.overlayView.updateRaw(detections, scannedIds)
            viewModel.gridLiveData.value?.let { grid ->
                binding.gridOverview.updateGrid(grid, detections.map { it.value }.toSet())
            }
        }

        viewModel.scanState.observe(this) { state ->
            when (state) {
                ScannerViewModel.ScanState.SCANNING -> {
                    binding.tvScanState.text = "● Scanning"
                    binding.tvScanState.setTextColor(getColor(R.color.accent_cyan))
                    binding.btnAddRow.isEnabled  = true
                    binding.btnAddRow.alpha      = 1f
                    binding.btnFinish.isEnabled  = true
                }
                ScannerViewModel.ScanState.EXTENSION -> {
                    binding.tvScanState.text = "↓ Point camera below last row"
                    binding.tvScanState.setTextColor(getColor(R.color.accent_yellow))
                    // Disable Add Row until new codes are placed (state returns to SCANNING)
                    binding.btnAddRow.isEnabled = false
                    binding.btnAddRow.alpha     = 0.4f
                    binding.btnFinish.isEnabled = true
                }
                ScannerViewModel.ScanState.FINISHED -> {
                    binding.tvScanState.text = "✓ Session complete"
                    binding.tvScanState.setTextColor(getColor(R.color.accent_green))
                    binding.btnAddRow.isEnabled  = false
                    binding.btnAddRow.alpha      = 0.3f
                    binding.btnFinish.isEnabled  = false
                    binding.btnFinish.alpha      = 0.3f
                }
            }
        }

        viewModel.newCodeAdded.observe(this) { id ->
            id ?: return@observe
            binding.tvLastCode.text       = "Last: $id"
            binding.tvLastCode.visibility = View.VISIBLE
        }
    }

    // ── Camera ─────────────────────────────────────────────────────────────────

    @SuppressLint("UnsafeOptInUsageError")
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val preview = Preview.Builder()
                .setResolutionSelector(CameraConfig.buildPreviewResolutionSelector())
                .build()
                .also { it.setSurfaceProvider(binding.cameraPreview.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(CameraConfig.buildAnalysisResolutionSelector())
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
                .also { it.setAnalyzer(analysisExecutor) { proxy -> qrScanner.processFrame(proxy) } }

            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                setupZoom()
            } catch (e: Exception) {
                Toast.makeText(this, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupZoom() {
        camera?.cameraInfo?.zoomState?.observe(this) { state ->
            minZoom = state.minZoomRatio
            maxZoom = state.maxZoomRatio
        }
        currentZoom = 1f
        binding.tvZoomLevel.text = "1.0×"
    }

    private fun setZoom(ratio: Float) {
        currentZoom = ratio.coerceIn(minZoom, maxZoom)
        camera?.cameraControl?.setZoomRatio(currentZoom)
        binding.tvZoomLevel.text = String.format("%.1f×", currentZoom)
    }

    private fun adjustZoom(delta: Float) {
        val newProgress = ((currentZoom + delta - minZoom) / (maxZoom - minZoom) * 100)
            .toInt().coerceIn(0, 100)
        binding.seekbarZoom.progress = newProgress
        setZoom(currentZoom + delta)
    }
}
