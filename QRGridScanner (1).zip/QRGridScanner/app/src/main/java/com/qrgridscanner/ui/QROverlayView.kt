package com.qrgridscanner.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.qrgridscanner.model.DetectedQR

/**
 * QROverlayView draws translucent blue bounding boxes over detected QR codes
 * on top of the camera preview.
 *
 * Coordinates are supplied as normalised (0..1) values and mapped to view pixels.
 * The view also draws a small label with the QR value (truncated if long).
 */
class QROverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class OverlayEntry(
        val det: DetectedQR,
        val isNew: Boolean   // true = bright blue; false = muted (already in grid)
    )

    private var entries: List<OverlayEntry> = emptyList()

    // Paint for already-scanned (confirmed) codes
    private val confirmedFillPaint = Paint().apply {
        color = Color.argb(60, 0, 120, 255)
        style = Paint.Style.FILL
    }
    private val confirmedStrokePaint = Paint().apply {
        color = Color.argb(230, 0, 120, 255)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    // Paint for newly detected codes (brighter)
    private val newFillPaint = Paint().apply {
        color = Color.argb(80, 0, 200, 255)
        style = Paint.Style.FILL
    }
    private val newStrokePaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val labelBgPaint = Paint().apply {
        color = Color.argb(180, 0, 80, 200)
        style = Paint.Style.FILL
    }
    private val labelTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 30f
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
    }
    private val cornerPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    /** Update the set of codes to draw and trigger a redraw. */
    fun updateOverlay(newEntries: List<OverlayEntry>) {
        entries = newEntries
        invalidate()
    }

    /** Convenience: supply just the raw detections (all treated as new). */
    fun updateRaw(detections: List<DetectedQR>, scannedIds: Set<String>) {
        entries = detections.map { OverlayEntry(it, !scannedIds.contains(it.value)) }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        for (entry in entries) {
            val det = entry.det

            // Map normalised coords → view pixels
            val left   = det.normLeft   * w
            val top    = det.normTop    * h
            val right  = det.normRight  * w
            val bottom = det.normBottom * h

            val rect = RectF(left, top, right, bottom)
            val fillPaint   = if (entry.isNew) newFillPaint   else confirmedFillPaint
            val strokePaint = if (entry.isNew) newStrokePaint else confirmedStrokePaint

            // Filled rect
            canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
            canvas.drawRoundRect(rect, 12f, 12f, strokePaint)

            // Animated corner brackets (make it look like a scanner)
            val cornerLen = minOf(rect.width(), rect.height()) * 0.25f
            drawCornerBrackets(canvas, rect, cornerLen)

            // Label background + text
            val label = if (det.value.length > 18) det.value.take(15) + "…" else det.value
            val textW = labelTextPaint.measureText(label)
            val labelRect = RectF(left, top - 36f, left + textW + 16f, top)
            canvas.drawRoundRect(labelRect, 6f, 6f, labelBgPaint)
            canvas.drawText(label, left + 8f, top - 10f, labelTextPaint)
        }
    }

    private fun drawCornerBrackets(canvas: Canvas, rect: RectF, len: Float) {
        val l = rect.left; val t = rect.top
        val r = rect.right; val b = rect.bottom

        // Top-left
        canvas.drawLine(l, t, l + len, t, cornerPaint)
        canvas.drawLine(l, t, l, t + len, cornerPaint)
        // Top-right
        canvas.drawLine(r, t, r - len, t, cornerPaint)
        canvas.drawLine(r, t, r, t + len, cornerPaint)
        // Bottom-left
        canvas.drawLine(l, b, l + len, b, cornerPaint)
        canvas.drawLine(l, b, l, b - len, cornerPaint)
        // Bottom-right
        canvas.drawLine(r, b, r - len, b, cornerPaint)
        canvas.drawLine(r, b, r, b - len, cornerPaint)
    }
}
