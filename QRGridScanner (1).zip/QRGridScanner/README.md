# QR Grid Scanner — Android App

A professional Android application to **scan, position, and assemble QR codes** arranged in a physical grid using the phone camera + IMU sensors. Optimised for Samsung Galaxy S25 Ultra.

---

## Features

| Feature | Detail |
|---|---|
| **ML Kit QR scanning** | Hardware-accelerated, QR_CODE format only for speed |
| **Live camera overlay** | Blue bounding boxes drawn over detected codes in real time |
| **IMU grid positioning** | Rotation vector + linear acceleration sensor fusion to estimate camera pose |
| **Grid assembler** | Automatic row/column clustering from world-space positions |
| **Duplicate detection** | Each QR value is stored once; re-detections are silently ignored |
| **Grid overview mini-map** | Live thumbnail of the assembled grid shown at the bottom of the scanner |
| **Camera zoom** | SeekBar + ±0.5× step buttons; full zoom range of the device exposed |
| **Best-resolution camera** | Requests 4K analysis stream (ideal for S25 Ultra rear camera) |
| **JSON export** | One-tap save of the full grid (row, col, worldX, worldY per code) |

---

## Architecture

```
app/
├── model/          Models.kt            — QRCode, QRGrid, DetectedQR, ImuSnapshot, ScanSession
├── imu/            ImuManager.kt        — Sensor fusion: orientation + dead-reckoning translation
├── scanner/        QRScanner.kt         — ML Kit barcode processing per CameraX frame
│                   CameraConfig.kt      — Resolution selector (4K→QHD→FHD fallback)
├── grid/           GridAssembler.kt     — World-position clustering → (row, col) assignment
└── ui/
    ├── MainActivity.kt        — Landing screen
    ├── ScannerActivity.kt     — Camera + overlay + zoom controls
    ├── ScannerViewModel.kt    — LiveData, coordinates IMU / scanner / grid
    ├── GridViewActivity.kt    — Full grid RecyclerView
    ├── QROverlayView.kt       — Custom View: blue boxes + corner brackets on camera frame
    └── GridOverviewView.kt    — Custom View: mini-map of the assembled grid
```

---

## How the Grid Positioning Works

1. **Scanning starts** → IMU origin is reset to (0, 0, 0).
2. **Phone moves** over the grid → Linear acceleration is integrated (double integration) to give a world-space (X, Y) position estimate.
3. **QR code detected** → The code is stored with the current world position.
4. **GridAssembler clusters** all stored X values into columns and Y values into rows using a configurable distance threshold (default 8 cm).
5. **Row/column indices** are assigned by sorting the cluster centroids.
6. The grid is **re-clustered on every new detection** so positions self-correct as more reference points become available.

> **Tip:** For best accuracy, hold the phone parallel to the grid surface (portrait, camera facing down or at a shallow angle). Slow, steady movement reduces IMU drift.

---

## Camera Resolution Strategy (Samsung S25 Ultra)

The S25 Ultra rear camera supports up to 200 MP native, but ML Kit's barcode detector works best with 4K input:

```
Priority order for ImageAnalysis stream:
  1. 7680 × 4320 (8K UHD)  ← requested first (S25 Ultra native tier)
  2. 3840 × 2160 (4K UHD)  ← CameraX fallback 1
  3. 2560 × 1440 (QHD)     ← CameraX fallback 2
  4. 1920 × 1080 (FHD)     ← CameraX fallback 3
  5. 1280 × 720  (HD)      ← minimum acceptable

Preview stream: 16:9 aspect ratio, highest the surface can display.
```

This is configured in `CameraConfig.kt` via `ResolutionSelector` + `ResolutionStrategy`.

---

## Building the App

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- JDK 17
- A physical device (IMU sensors are not well-emulated on AVD)

### Steps

```bash
# Clone / extract the project
cd QRGridScanner

# Build debug APK
./gradlew assembleDebug

# Install on connected device
./gradlew installDebug
```

The APK is output to `app/build/outputs/apk/debug/app-debug.apk`.

---

## Permissions Required

| Permission | Reason |
|---|---|
| `CAMERA` | Camera preview + QR scanning |
| `WRITE_EXTERNAL_STORAGE` (≤API 28) | JSON export to files dir |

---

## Dependencies

```groovy
// CameraX 1.3.1
androidx.camera:camera-core
androidx.camera:camera-camera2
androidx.camera:camera-lifecycle
androidx.camera:camera-view
androidx.camera:camera-extensions

// ML Kit
com.google.mlkit:barcode-scanning:17.2.0

// Kotlin Coroutines, Gson, Material Design, etc.
```

---

## Output Format (JSON)

When you press **Save**, a file like `qrgrid_20250101_120000.json` is written to the app's internal files directory. Contents:

```json
[
  {
    "id": "UNIQUE_QR_VALUE",
    "gridCol": 0,
    "gridRow": 0,
    "worldX": 0.0,
    "worldY": 0.0,
    "scanTime": 1700000000000,
    "confidence": 1.0
  },
  ...
]
```

You can retrieve this file via Android Studio → Device File Explorer → `/data/data/com.qrgridscanner/files/`.

---

## Known Limitations & Future Improvements

| Limitation | Suggested Fix |
|---|---|
| IMU dead-reckoning drifts over time | Use ARCore Augmented Reality anchors instead |
| Grid clustering needs ≥2 codes per row/col to converge | Pre-configure expected grid dimensions |
| No persistence between app sessions | Add Room database |
| No visual "missed cells" indicator | Track expected total cell count |
| Zoom pinch gesture not implemented | Add `ScaleGestureDetector` to PreviewView |

---

## License
MIT — free to use and modify.
