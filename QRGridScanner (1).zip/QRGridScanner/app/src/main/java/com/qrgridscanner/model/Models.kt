package com.qrgridscanner.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Represents a single QR code placed in the assembled grid.
 *
 * @param id         Unique decoded QR string
 * @param gridCol    Column index (0-based, -1 = unassigned)
 * @param gridRow    Row index    (0-based, -1 = unassigned)
 * @param normCx     Normalised pixel X centroid at time of first detection (0..1)
 * @param normCy     Normalised pixel Y centroid at time of first detection (0..1)
 * @param scanTime   Epoch millis when first detected
 * @param confidence 1.0 = placed by direct pixel evidence; <1.0 = approximate
 */
@Parcelize
data class QRCode(
    val id: String,
    var gridCol: Int   = -1,
    var gridRow: Int   = -1,
    var normCx: Float  = 0f,
    var normCy: Float  = 0f,
    var scanTime: Long = System.currentTimeMillis(),
    var confidence: Float = 1f
) : Parcelable

/**
 * The fully assembled grid of QR codes, stored as a map keyed by QR value.
 */
data class QRGrid(
    val codes: MutableMap<String, QRCode> = mutableMapOf(),
    var totalCols: Int = 0,
    var totalRows: Int = 0
) {
    fun contains(id: String) = codes.containsKey(id)

    fun add(code: QRCode): Boolean {
        if (contains(code.id)) return false
        codes[code.id] = code
        return true
    }

    fun getAll(): List<QRCode> = codes.values.toList()
    fun count()  = codes.size

    fun recalcDimensions() {
        if (codes.isEmpty()) { totalCols = 0; totalRows = 0; return }
        totalCols = (codes.values.maxOfOrNull { it.gridCol } ?: 0) + 1
        totalRows = (codes.values.maxOfOrNull { it.gridRow } ?: 0) + 1
    }
}

/**
 * One detected QR code within a camera frame.
 *
 * normCx/normCy — centroid averaged from ML Kit corner points (accurate even for
 *                 rotated / perspective-distorted codes).
 * normLeft..normBottom — axis-aligned bounding box (overlay drawing only).
 */
data class DetectedQR(
    val value: String,
    val normCx: Float,
    val normCy: Float,
    val normLeft: Float,
    val normTop: Float,
    val normRight: Float,
    val normBottom: Float
)

/**
 * All QR codes detected in a single camera frame.
 * This is the atomic unit consumed by GridAssembler.
 */
data class ScanFrame(
    val detections: List<DetectedQR>,
    val frameTimeMs: Long = System.currentTimeMillis()
)

/**
 * App-level session wrapper.
 */
data class ScanSession(
    val sessionId: String = java.util.UUID.randomUUID().toString(),
    val startTime: Long   = System.currentTimeMillis(),
    var endTime: Long     = 0L
)
