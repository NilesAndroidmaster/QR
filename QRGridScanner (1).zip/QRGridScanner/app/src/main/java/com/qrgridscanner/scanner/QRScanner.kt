package com.qrgridscanner.scanner

import android.annotation.SuppressLint
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.qrgridscanner.model.DetectedQR
import com.qrgridscanner.model.ScanFrame

/**
 * QRScanner wraps ML Kit barcode detection.
 *
 * Each camera frame is processed and — if at least one QR code is found —
 * emitted as a [ScanFrame] containing every code visible in that frame.
 *
 * Centroid accuracy
 * -----------------
 * We use ML Kit's four corner points (barcode.cornerPoints) rather than the
 * axis-aligned bounding box centre. This gives a geometrically correct centroid
 * even for rotated or perspective-distorted codes, which is critical for the
 * pixel-based row clustering in GridAssembler.
 *
 * Back-pressure
 * -------------
 * Only one frame is processed at a time. CameraX's STRATEGY_KEEP_ONLY_LATEST
 * ensures we always work on the freshest frame rather than a stale queue.
 */
class QRScanner {

    private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
        .build()

    private val scanner = BarcodeScanning.getClient(options)

    /** Receives every frame that contains ≥1 QR code. Called on the analysis thread. */
    var onFrameDetected: ((ScanFrame) -> Unit)? = null

    @Volatile
    private var isProcessing = false

    @SuppressLint("UnsafeOptInUsageError")
    fun processFrame(imageProxy: ImageProxy) {
        if (isProcessing) { imageProxy.close(); return }
        isProcessing = true

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); isProcessing = false; return }

        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val image  = InputImage.fromMediaImage(mediaImage, rotationDegrees)
        val width  = imageProxy.width.toFloat()
        val height = imageProxy.height.toFloat()

        scanner.process(image)
            .addOnSuccessListener { barcodes ->
                if (barcodes.isEmpty()) return@addOnSuccessListener

                val detected = barcodes.mapNotNull { barcode ->
                    val value   = barcode.rawValue ?: return@mapNotNull null
                    val corners = barcode.cornerPoints
                    val box     = barcode.boundingBox ?: return@mapNotNull null

                    // ── Centroid from corner points ────────────────────────────
                    val (cx, cy) = if (corners != null && corners.size == 4) {
                        Pair(
                            corners.map { it.x }.average().toFloat(),
                            corners.map { it.y }.average().toFloat()
                        )
                    } else {
                        Pair(box.exactCenterX(), box.exactCenterY())
                    }

                    DetectedQR(
                        value      = value,
                        normCx     = cx / width,
                        normCy     = cy / height,
                        normLeft   = box.left   / width,
                        normTop    = box.top    / height,
                        normRight  = box.right  / width,
                        normBottom = box.bottom / height
                    )
                }

                if (detected.isNotEmpty()) {
                    onFrameDetected?.invoke(ScanFrame(detections = detected))
                }
            }
            .addOnCompleteListener {
                imageProxy.close()
                isProcessing = false
            }
    }

    fun close() = scanner.close()
}
