package com.qrgridscanner.grid

import com.qrgridscanner.model.DetectedQR
import com.qrgridscanner.model.QRCode
import com.qrgridscanner.model.QRGrid
import com.qrgridscanner.model.ScanFrame
import kotlin.math.abs

/**
 * GridAssembler — pixel-based sub-grid stitching with row-extension mode
 * =======================================================================
 *
 * STATE MACHINE
 * -------------
 *  SCANNING     — default; camera is over an already-scanned region or
 *                 extending it naturally. Stitching via shared-code anchors.
 *  EXTENSION    — user pressed "Add Row". Next codes are placed below
 *                 rowFloor. Already-scanned codes visible in frame act as
 *                 column anchors. Transitions back to SCANNING once the
 *                 first new code is placed in extension mode.
 *
 * ALGORITHM (3 phases, IMU completely removed)
 * --------------------------------------------
 *
 * Phase 1 — Intra-frame local layout (exact, pixel-based)
 *   Given all codes visible in one frame:
 *   a. Cluster normCy values → local row indices
 *   b. Within each local row, sort by normCx → local col indices
 *   Result: every code gets a (localRow, localCol) relative to that frame.
 *
 * Phase 2 — Stitch via shared-code anchors (exact)
 *   Find codes from the frame already placed in masterGrid.
 *   Each shared code gives: rowOffset = masterRow - localRow
 *                           colOffset = masterCol - localCol
 *   Take median offset (robust to outliers from mis-clustered codes).
 *   Place new codes at (localRow + rowOffset, localCol + colOffset).
 *
 * Phase 3 — Extension mode (Add Row)
 *   rowFloor = max gridRow currently in masterGrid.
 *   For each new code in the frame:
 *   a. If shared anchor exists → inherit its gridCol exactly (column anchor).
 *      Place new code at (rowFloor + 1 + localRow, anchorCol + localColDelta).
 *   b. If no shared anchor → place at (rowFloor + 1 + localRow, localCol).
 *      Column index comes from intra-frame ordering only.
 *
 * GLOBAL RE-CLUSTER
 * -----------------
 *   After every stitch, all placed codes' stored normCy / normCx values
 *   are re-clustered globally. This corrects for slight camera-angle
 *   differences between frames that would otherwise put physically-aligned
 *   codes into different row/col indices.
 *   The re-cluster uses the same adaptive tolerance used for intra-frame
 *   clustering, so it tightens as more data is seen.
 *
 * NEGATIVE INDEX NORMALISATION
 * ----------------------------
 *   Stitching can produce negative indices (e.g. camera pans left of
 *   first frame). After every stitch we shift all indices so min = 0.
 */
class GridAssembler {

    enum class State { SCANNING, EXTENSION }

    // ── Public state ──────────────────────────────────────────────────────────

    val masterGrid = QRGrid()
    var state: State = State.SCANNING
        private set

    /** Maximum gridRow currently placed. Updated after every stitch. */
    private var rowFloor: Int = 0

    /**
     * Adaptive clustering tolerances. Calibrated from observed intra-frame
     * centroid gaps as more frames are processed.
     * Default: assume codes are ~10% of frame height/width apart.
     */
    private var rowTolerance: Float = 0.10f   // fraction of image height
    private var colTolerance: Float = 0.10f   // fraction of image width

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Process a new camera frame.
     * @return number of NEW codes added (0 = all already known).
     */
    fun processFrame(frame: ScanFrame): Int {
        if (frame.detections.isEmpty()) return 0

        calibrate(frame.detections)
        val subGrid = buildSubGrid(frame.detections)

        val added = when {
            masterGrid.count() == 0 -> bootstrap(subGrid)
            state == State.EXTENSION -> extendGrid(subGrid)
            else -> stitchOrAppend(subGrid)
        }

        if (added > 0) {
            normaliseIndices()
            globalRecluster()
            masterGrid.recalcDimensions()
            rowFloor = masterGrid.getAll().maxOfOrNull { it.gridRow } ?: 0
        }
        return added
    }

    /**
     * Signal that the user is moving the camera to a region BELOW the current
     * scan area. Puts the assembler into EXTENSION mode.
     */
    fun addRow() {
        rowFloor = masterGrid.getAll().maxOfOrNull { it.gridRow } ?: 0
        state = State.EXTENSION
    }

    // ── Phase 1: Intra-frame sub-grid ─────────────────────────────────────────

    private fun buildSubGrid(detections: List<DetectedQR>): SubGrid {
        // ── Cluster by normCy into local rows ─────────────────────────────
        data class RowCluster(var centroid: Float, val members: MutableList<DetectedQR>)

        val clusters = mutableListOf<RowCluster>()
        for (det in detections.sortedBy { it.normCy }) {
            val nearest = clusters.minByOrNull { abs(it.centroid - det.normCy) }
            if (nearest != null && abs(nearest.centroid - det.normCy) < rowTolerance * 0.5f) {
                nearest.members.add(det)
                nearest.centroid = nearest.members.map { it.normCy }.average().toFloat()
            } else {
                clusters.add(RowCluster(det.normCy, mutableListOf(det)))
            }
        }
        clusters.sortBy { it.centroid }

        // ── Assign local (row, col) ────────────────────────────────────────
        val entries = mutableListOf<SubGridEntry>()
        for ((localRow, cluster) in clusters.withIndex()) {
            for ((localCol, det) in cluster.members.sortedBy { it.normCx }.withIndex()) {
                entries.add(SubGridEntry(det, localRow, localCol))
            }
        }
        return SubGrid(entries)
    }

    // ── Bootstrap: first frame ────────────────────────────────────────────────

    private fun bootstrap(subGrid: SubGrid): Int {
        var added = 0
        for (entry in subGrid.entries) {
            masterGrid.add(QRCode(
                id        = entry.det.value,
                gridRow   = entry.localRow,
                gridCol   = entry.localCol,
                worldX    = entry.det.normCx,
                worldY    = entry.det.normCy,
                confidence = 1.0f
            ))
            added++
        }
        state = State.SCANNING
        return added
    }

    // ── Phase 2: Normal stitching via shared-code anchors ────────────────────

    private fun stitchOrAppend(subGrid: SubGrid): Int {
        val offsets = computeOffsets(subGrid) ?: return 0
        val (rowOff, colOff) = offsets
        var added = 0
        for (entry in subGrid.entries) {
            if (masterGrid.contains(entry.det.value)) continue
            masterGrid.add(QRCode(
                id         = entry.det.value,
                gridRow    = entry.localRow + rowOff,
                gridCol    = entry.localCol + colOff,
                worldX     = entry.det.normCx,
                worldY     = entry.det.normCy,
                confidence = 1.0f
            ))
            added++
        }
        return added
    }

    private fun computeOffsets(subGrid: SubGrid): Pair<Int, Int>? {
        val rowOffsets = mutableListOf<Int>()
        val colOffsets = mutableListOf<Int>()
        for (entry in subGrid.entries) {
            val placed = masterGrid.codes[entry.det.value] ?: continue
            rowOffsets.add(placed.gridRow - entry.localRow)
            colOffsets.add(placed.gridCol - entry.localCol)
        }
        if (rowOffsets.isEmpty()) return null
        // Median is robust against one mis-clustered anchor
        return Pair(
            rowOffsets.sorted()[rowOffsets.size / 2],
            colOffsets.sorted()[colOffsets.size / 2]
        )
    }

    // ── Phase 3: Row extension mode ───────────────────────────────────────────

    /**
     * In extension mode the user has moved the camera below the last scanned row.
     *
     * Strategy:
     *   a. Find any already-scanned codes visible in this frame (column anchors).
     *      These are codes from the bottom of the previous scan that are still
     *      partially visible.
     *   b. For each anchor: it tells us exactly which gridCol maps to which
     *      localCol in this frame. Use median offset for robustness.
     *   c. New codes are placed at (rowFloor + 1 + localRow, localCol + colOffset).
     *   d. If NO anchors at all: place purely from local col ordering
     *      (col 0 = leftmost new code seen).
     *   e. After first placement, revert to SCANNING so natural stitching
     *      takes over for the rest of this row.
     */
    private fun extendGrid(subGrid: SubGrid): Int {
        val colOffsets = mutableListOf<Int>()
        for (entry in subGrid.entries) {
            val placed = masterGrid.codes[entry.det.value] ?: continue
            colOffsets.add(placed.gridCol - entry.localCol)
        }
        val colOff = if (colOffsets.isNotEmpty())
            colOffsets.sorted()[colOffsets.size / 2]
        else
            0   // no anchors: leftmost new code becomes col 0 in this row

        var added = 0
        for (entry in subGrid.entries) {
            if (masterGrid.contains(entry.det.value)) continue
            masterGrid.add(QRCode(
                id         = entry.det.value,
                gridRow    = rowFloor + 1 + entry.localRow,
                gridCol    = entry.localCol + colOff,
                worldX     = entry.det.normCx,
                worldY     = entry.det.normCy,
                confidence = if (colOffsets.isNotEmpty()) 1.0f else 0.85f
            ))
            added++
        }

        // Return to normal scanning — subsequent frames stitch naturally
        if (added > 0) state = State.SCANNING
        return added
    }

    // ── Global re-cluster ─────────────────────────────────────────────────────

    /**
     * After stitching, re-assign gridRow and gridCol to ALL codes by
     * clustering their stored normCy / normCx values globally.
     *
     * This ensures codes from different frames that belong to the same
     * physical row/column (but have slightly different normCy/normCx due
     * to camera angle shifts) end up with consistent indices.
     */
    private fun globalRecluster() {
        val codes = masterGrid.getAll()
        if (codes.size < 2) return

        // ── Re-cluster rows by normCy ──────────────────────────────────────
        data class Cluster(var centroid: Float, val ids: MutableList<String>)

        fun cluster(values: List<Pair<String, Float>>, tolerance: Float): Map<String, Int> {
            val clusters = mutableListOf<Cluster>()
            for ((id, v) in values.sortedBy { it.second }) {
                val nearest = clusters.minByOrNull { abs(it.centroid - v) }
                if (nearest != null && abs(nearest.centroid - v) < tolerance) {
                    nearest.ids.add(id)
                    nearest.centroid = nearest.ids
                        .mapNotNull { cid -> values.find { it.first == cid }?.second }
                        .average().toFloat()
                } else {
                    clusters.add(Cluster(v, mutableListOf(id)))
                }
            }
            // Sort clusters by centroid, assign index
            clusters.sortBy { it.centroid }
            val result = mutableMapOf<String, Int>()
            clusters.forEachIndexed { idx, c -> c.ids.forEach { result[it] = idx } }
            return result
        }

        val rowMap = cluster(codes.map { Pair(it.id, it.worldY) }, rowTolerance * 0.6f)
        val colMap = cluster(codes.map { Pair(it.id, it.worldX) }, colTolerance * 0.6f)

        for (code in codes) {
            rowMap[code.id]?.let { code.gridRow = it }
            colMap[code.id]?.let { code.gridCol = it }
        }
    }

    // ── Calibration ───────────────────────────────────────────────────────────

    /**
     * Update row/col tolerance estimates from observed intra-frame centroid gaps.
     * Uses exponential moving average so early noisy estimates don't dominate.
     */
    private fun calibrate(detections: List<DetectedQR>) {
        if (detections.size < 2) return

        val minDy = detections.map { it.normCy }.sorted()
            .zipWithNext().map { (a, b) -> b - a }.filter { it > 0.02f }.minOrNull()

        val minDx = detections.map { it.normCx }.sorted()
            .zipWithNext().map { (a, b) -> b - a }.filter { it > 0.02f }.minOrNull()

        if (minDy != null) rowTolerance = rowTolerance * 0.75f + minDy * 0.25f
        if (minDx != null) colTolerance = colTolerance * 0.75f + minDx * 0.25f
    }

    // ── Index normalisation ───────────────────────────────────────────────────

    private fun normaliseIndices() {
        val codes = masterGrid.getAll().takeIf { it.isNotEmpty() } ?: return
        val minRow = codes.minOf { it.gridRow }
        val minCol = codes.minOf { it.gridCol }
        if (minRow == 0 && minCol == 0) return
        codes.forEach { it.gridRow -= minRow; it.gridCol -= minCol }
    }

    // ── Public helpers ────────────────────────────────────────────────────────

    fun getGrid(): QRGrid = masterGrid

    fun getSortedCodes(): List<QRCode> =
        masterGrid.getAll().sortedWith(compareBy({ it.gridRow }, { it.gridCol }))

    // ── Internal types ────────────────────────────────────────────────────────

    private data class SubGridEntry(val det: DetectedQR, val localRow: Int, val localCol: Int)
    private data class SubGrid(val entries: List<SubGridEntry>)
}
