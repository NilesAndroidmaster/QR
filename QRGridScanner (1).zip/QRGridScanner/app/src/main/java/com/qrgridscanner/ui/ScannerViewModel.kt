package com.qrgridscanner.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.qrgridscanner.grid.GridAssembler
import com.qrgridscanner.model.DetectedQR
import com.qrgridscanner.model.QRCode
import com.qrgridscanner.model.QRGrid
import com.qrgridscanner.model.ScanFrame
import com.qrgridscanner.model.ScanSession
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScannerViewModel(app: Application) : AndroidViewModel(app) {

    enum class ScanState { SCANNING, EXTENSION, FINISHED }

    private val assembler = GridAssembler()
    private val session   = ScanSession()

    // ── LiveData observed by ScannerActivity ──────────────────────────────────
    val scannedCount     = MutableLiveData(0)
    val gridLiveData     = MutableLiveData<QRGrid>()
    val activeDetections = MutableLiveData<List<DetectedQR>>(emptyList())
    val scanState        = MutableLiveData(ScanState.SCANNING)
    val newCodeAdded     = MutableLiveData<String?>(null)

    // ── Frame processing ──────────────────────────────────────────────────────

    /**
     * Called from the CameraX analysis executor for every frame with ≥1 QR code.
     * Heavy work is moved to Default dispatcher so the camera thread is never blocked.
     */
    fun onFrameDetected(frame: ScanFrame) {
        activeDetections.postValue(frame.detections)

        // Skip processing if session is finished
        if (scanState.value == ScanState.FINISHED) return

        viewModelScope.launch(Dispatchers.Default) {
            val added = assembler.processFrame(frame)
            if (added > 0) {
                val newest = assembler.getSortedCodes().lastOrNull { it.scanTime > 0 }
                newCodeAdded.postValue(newest?.id)
                scannedCount.postValue(assembler.getGrid().count())
                gridLiveData.postValue(assembler.getGrid())
                // Mirror assembler state → UI state
                syncState()
            }
        }
    }

    // ── State transitions ─────────────────────────────────────────────────────

    /** User tapped "Add Row" — signal assembler and update UI state. */
    fun addRow() {
        if (scanState.value == ScanState.FINISHED) return
        assembler.addRow()
        syncState()
    }

    /** User tapped "Finish" — freeze scanning. */
    fun finish() {
        scanState.postValue(ScanState.FINISHED)
        session.endTime = System.currentTimeMillis()
    }

    private fun syncState() {
        val uiState = when (assembler.state) {
            GridAssembler.State.SCANNING  -> ScanState.SCANNING
            GridAssembler.State.EXTENSION -> ScanState.EXTENSION
        }
        // Don't overwrite FINISHED
        if (scanState.value != ScanState.FINISHED) {
            scanState.postValue(uiState)
        }
    }

    // ── Accessors used by GridViewActivity ────────────────────────────────────

    fun getGrid(): QRGrid = assembler.getGrid()

    fun getSortedCodes(): List<QRCode> = assembler.getSortedCodes()

    // ── Persistence ───────────────────────────────────────────────────────────

    fun saveResults(onDone: (File) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val json      = Gson().toJson(assembler.getSortedCodes())
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file      = File(getApplication<Application>().filesDir, "qrgrid_$timestamp.json")
            file.writeText(json)
            launch(Dispatchers.Main) { onDone(file) }
        }
    }
}
