package com.qrgridscanner.imu

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.qrgridscanner.model.ImuSnapshot
import kotlin.math.sqrt

/**
 * ImuManager wraps Android SensorManager to provide:
 *  - Device orientation via rotation vector sensor (or gyroscope fallback)
 *  - Linear acceleration integration for dead-reckoning translation
 *
 * The translation is relative to where scanning began (reset on [reset]).
 * It is intentionally simple – for a production app you would use a proper
 * Kalman filter, but this gives a usable result for a stationary grid scan
 * where the phone moves slowly over the surface.
 */
class ImuManager(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    // Rotation
    private val rotationSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    // Translation via linear acceleration
    private val linAccelSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val velocity = FloatArray(3)    // m/s in world frame
    val position = FloatArray(3)            // m in world frame (relative to start)

    private var lastAccelTimestamp = 0L

    // Callbacks
    var onUpdate: ((ImuSnapshot) -> Unit)? = null

    // ---------- Lifecycle ----------

    fun start() {
        rotationSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        linAccelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    /** Reset dead-reckoning origin (call when scan starts). */
    fun reset() {
        velocity.fill(0f)
        position.fill(0f)
        lastAccelTimestamp = 0L
    }

    // ---------- SensorEventListener ----------

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> handleRotation(event)
            Sensor.TYPE_LINEAR_ACCELERATION -> handleAcceleration(event)
        }
    }

    private fun handleRotation(event: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        SensorManager.getOrientation(rotationMatrix, orientationAngles)
        notifyUpdate()
    }

    private fun handleAcceleration(event: SensorEvent) {
        if (lastAccelTimestamp == 0L) {
            lastAccelTimestamp = event.timestamp
            return
        }
        val dt = (event.timestamp - lastAccelTimestamp) * 1e-9f   // ns → s
        lastAccelTimestamp = event.timestamp

        // Rotate acceleration from device to world frame
        val aWorld = FloatArray(3)
        val r = rotationMatrix
        val ax = event.values[0]; val ay = event.values[1]; val az = event.values[2]
        aWorld[0] = r[0] * ax + r[1] * ay + r[2] * az
        aWorld[1] = r[3] * ax + r[4] * ay + r[5] * az
        aWorld[2] = r[6] * ax + r[7] * ay + r[8] * az

        // Zero-velocity update: ignore tiny accelerations (reduces drift)
        val mag = sqrt(aWorld[0] * aWorld[0] + aWorld[1] * aWorld[1] + aWorld[2] * aWorld[2])
        if (mag < 0.05f) return

        // Integrate velocity → position (simple Euler)
        for (i in 0..2) {
            velocity[i] += aWorld[i] * dt
            position[i] += velocity[i] * dt
        }
    }

    private fun notifyUpdate() {
        onUpdate?.invoke(
            ImuSnapshot(
                rotationMatrix = rotationMatrix.copyOf(),
                translationX = position[0],
                translationY = position[1],
                translationZ = position[2]
            )
        )
    }

    // ---------- Helpers ----------

    /** Returns azimuth (yaw) in radians. */
    fun getAzimuth() = orientationAngles[0]

    /** Returns pitch in radians. */
    fun getPitch() = orientationAngles[1]

    /** Returns roll in radians. */
    fun getRoll() = orientationAngles[2]

    /** Current 2-D position on the scanning plane (X-right, Y-down). */
    fun getPosition2D() = Pair(position[0], position[1])
}
