package com.qrgridscanner.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.qrgridscanner.model.QRCode
import com.qrgridscanner.model.QRGrid

/**
 * GridOverviewView — live mini-map of the assembled grid shown during scanning.
 *
 * Visual conventions
 * ------------------
 *  Scanned code     → solid blue cell
 *  Highlighted code → bright cyan (code currently visible in camera frame)
 *  Empty slot       → dim grey outline cell
 *
 * Layout
 * ------
 *  Cells auto-size to fill available width/height while preserving the grid
 *  aspect ratio. Minimum cell size is 8dp so small grids don't become invisible.
 */
class GridOverviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var grid: QRGrid? = null
    private var highlightedIds: Set<String> = emptySet()

    // ── Paints ────────────────────────────────────────────────────────────────

    private val scannedFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 0, 120, 255)
        style = Paint.Style.FILL
    }
    private val highlightFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 0, 210, 255)
        style = Paint.Style.FILL
    }
    private val emptyFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(25, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val emptyStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }
    private val cellStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun updateGrid(g: QRGrid, highlighted: Set<String> = emptySet()) {
        grid = g
        highlightedIds = highlighted
        invalidate()
    }

    // ── Draw ──────────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val g = grid?.takeIf { it.count() > 0 } ?: return

        val cols = g.totalCols.coerceAtLeast(1)
        val rows = g.totalRows.coerceAtLeast(1)

        val pad  = 4f
        val cellW = ((width  - 2 * pad) / cols).coerceAtLeast(8f)
        val cellH = ((height - 2 * pad) / rows).coerceAtLeast(8f)
        val cell  = minOf(cellW, cellH)   // keep cells square

        labelPaint.textSize = (cell * 0.30f).coerceIn(6f, 14f)

        // Build lookup map for fast access
        val lookup = g.getAll().associateBy { Pair(it.gridRow, it.gridCol) }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val left  = pad + c * cell
                val top   = pad + r * cell
                val rect  = RectF(left + 1f, top + 1f, left + cell - 1f, top + cell - 1f)
                val code  = lookup[Pair(r, c)]

                when {
                    code != null && highlightedIds.contains(code.id) -> {
                        canvas.drawRoundRect(rect, 4f, 4f, highlightFill)
                        canvas.drawRoundRect(rect, 4f, 4f, cellStroke)
                    }
                    code != null -> {
                        canvas.drawRoundRect(rect, 4f, 4f, scannedFill)
                        canvas.drawRoundRect(rect, 4f, 4f, cellStroke)
                        if (cell >= 20f) {
                            canvas.drawText(
                                code.id.take(4),
                                rect.centerX(),
                                rect.centerY() + labelPaint.textSize / 3f,
                                labelPaint
                            )
                        }
                    }
                    else -> {
                        canvas.drawRoundRect(rect, 4f, 4f, emptyFill)
                        canvas.drawRoundRect(rect, 4f, 4f, emptyStroke)
                    }
                }
            }
        }
    }
}
