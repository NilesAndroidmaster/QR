package com.qrgridscanner.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.qrgridscanner.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnStartScan.setOnClickListener {
            startActivity(Intent(this, ScannerActivity::class.java))
        }

        binding.btnViewResults.setOnClickListener {
            startActivity(Intent(this, GridViewActivity::class.java))
        }
    }
}
